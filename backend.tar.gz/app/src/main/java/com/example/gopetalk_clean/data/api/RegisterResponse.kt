package com.example.gopetalk_clean.data.api

data class RegisterResponse(
    val message: String
)