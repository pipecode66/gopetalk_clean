package com.example.gopetalk_clean.data.api

data class LogoutResponse(
    val message: String
)