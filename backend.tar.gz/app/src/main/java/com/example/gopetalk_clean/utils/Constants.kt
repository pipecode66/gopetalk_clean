package com.example.gopetalk_clean.utils

object Constants {
    const val BASE_URL = "http://159.203.187.94/"
    const val WS_URL = "ws://159.203.187.94/ws"
}
