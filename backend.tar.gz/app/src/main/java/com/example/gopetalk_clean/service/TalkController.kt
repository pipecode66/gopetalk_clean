package com.example.gopetalk_clean.service


object TalkController {

}
